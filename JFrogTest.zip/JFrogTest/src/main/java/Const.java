public class Const {
    public static final String ARTIFACTORY_URL = "http://192.168.99.101:8081/artifactory";
    public static final String GET_USERS_METHOD = "/api/security/users";
//    public static final String GET_USER_DETAILS_METHOD = "api/security/users";
}
