import org.codehaus.jackson.annotate.JsonProperty;

import java.util.Objects;

public class User {
    private String name;

    private String uri;

    private String realm;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User)) return false;
        User user = (User) o;
        return Objects.equals(getName(), user.getName()) &&
                Objects.equals(getUri(), user.getUri()) &&
                Objects.equals(getRealm(), user.getRealm());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getName(), getUri(), getRealm());
    }

    public String getName() {
        return name;
    }

    public String getUri() {
        return uri;
    }

    public String getRealm() {
        return realm;
    }

    public User(
            @JsonProperty("name") String name,
            @JsonProperty("uri") String uri,
            @JsonProperty("realm") String realm) {

        this.name = name;
        this.uri = uri;
        this.realm = realm;
    }

}
