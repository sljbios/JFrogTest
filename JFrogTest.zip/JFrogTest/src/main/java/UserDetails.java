import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserDetails {
    private String name;
    private String password;

    private boolean admin;
    private boolean profileUpdatable;
    private boolean internalPasswordDisabled;
    private boolean offlineMode;
    private boolean disableUIAccess;

    private String realm;
    private String lastLoggedIn;
    private String email;
    private long lastLoggedInMillis;



    public String getName() {
        return name;
    }

    private String getPassword() { return password; }

    public boolean isAdmin() {
        return admin;
    }

    public boolean isProfileUpdatable() {
        return profileUpdatable;
    }

    public boolean isInternalPasswordDisabled() {
        return internalPasswordDisabled;
    }

    public boolean isOfflineMode() {
        return offlineMode;
    }

    public boolean isDisableUIAccess() {
        return disableUIAccess;
    }

    public String getLastLoggedIn() {
        return lastLoggedIn;
    }

    public long getLastLoggedInMillis() {
        return lastLoggedInMillis;
    }

    public String getRealm() {
        return realm;
    }

    public String getEmail() {
        return email;
    }

    public UserDetails(
            @JsonProperty("name") String name,
            @JsonProperty("password") String password,
            @JsonProperty("admin") Boolean admin,
            @JsonProperty("profileUpdatable") Boolean profileUpdatable,
            @JsonProperty("internalPasswordDisabled") Boolean internalPasswordDisabled,
            @JsonProperty("offlineMode") Boolean offlineMode,
            @JsonProperty("disableUIAccess") Boolean disableUIAccess,
            @JsonProperty("realm") String realm,
            @JsonProperty("lastLoggedIn") String lastLoggedIn,
            @JsonProperty("email") String email,
            @JsonProperty("lastLoggedInMillis") Long lastLoggedInMillis) {


        if(password != null) this.password = password;

        this.admin = (admin != null) ? admin : false;
        this.profileUpdatable = (profileUpdatable != null) ? profileUpdatable : true;
        this.internalPasswordDisabled = (internalPasswordDisabled != null) ? internalPasswordDisabled : false;

        if(name != null) this.name = name;
        if(email != null) this.email = email;

        if(offlineMode != null) this.offlineMode = offlineMode;
        if(disableUIAccess != null)this.disableUIAccess = disableUIAccess;
        if(realm != null) this.realm = realm;
        if(lastLoggedIn != null) this.lastLoggedIn = lastLoggedIn;
        if(lastLoggedInMillis != null) this.lastLoggedInMillis = lastLoggedInMillis;

    }

}
