import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import org.json.simple.JSONObject;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;



public class ApiResponseTest {


    private CredentialsProvider credentialsProvider = null;
    private RequestConfig requestConfig = null;
    private CloseableHttpClient httpClient = null;
    private List<User> userList = new ArrayList<>();
    private ObjectMapper mapper = new ObjectMapper();
    private UserDetails userDetails = null;
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");

    @Before
    public void prepareConnection() {

        credentialsProvider = new BasicCredentialsProvider();
        credentialsProvider.setCredentials(AuthScope.ANY,
                new UsernamePasswordCredentials("admin", "123456"));

        requestConfig = RequestConfig.custom()
                .setSocketTimeout(5000)
                .setConnectTimeout(5000)
                .setConnectionRequestTimeout(5000)
                .build();

        mapper.enable(SerializationConfig.Feature.INDENT_OUTPUT);
    }

    @Test
    public void getUsersMethodTest() {
        System.out.println("INFO: getUsersMethodTest started");

        httpClient =
                HttpClientBuilder.create().setDefaultCredentialsProvider(credentialsProvider).build();

        HttpGet httpGet = new HttpGet(Const.ARTIFACTORY_URL.concat(Const.GET_USERS_METHOD));
        httpGet.setConfig(requestConfig);

        try {
            HttpResponse response = httpClient.execute(httpGet);

            System.out.println("INFO: Response code: " + response.getStatusLine().getStatusCode());
            Assert.assertEquals("Response code not as expected ",
                    HttpStatus.SC_OK,
                    response.getStatusLine().getStatusCode());

            userList = mapper.readValue(response.getEntity().getContent(),
                    mapper.getTypeFactory().constructCollectionType(List.class, User.class));


        } catch (Exception e){

            System.out.println("ERROR: " + e.getMessage());

        } finally {
            try {
                httpClient.close();
            }
            catch (Exception ignored) {}
        }
        Assert.assertNotNull("ERROR: getUsersMethodTest failed. Users list is empty." +
                "At least admin user should exist", userList);

        System.out.println("INFO: getUsersMethodTest passed");
        System.out.println("---------------------------");
    }

    @Test
    public void getUserDetailsMethodTest() {

        System.out.println("INFO: getUserDetailsMethodTest started");

        if(userList.size() == 0) {
            // fill userList in case it's empty to get existing users
            getUsersMethodTest();
        }

        // use random to pick some arbitrary existing user
        Random rand = new Random();
        int index = rand.nextInt(userList.size());

        userDetails = getUserDetails(userList.get(index).getName());

        // Assert response is not empty
        Assert.assertNotNull("ERROR: getUserDetailsMethodTest failed. User details is null", userDetails);

        // Assert it's the same user as picked up from the list
        Assert.assertTrue("ERROR: getUserDetailsMethodTest failed. User Details are not as expected",
                userList.get(index).getName().equals(userDetails.getName()) &&
                userList.get(index).getRealm().equals(userDetails.getRealm()));

        System.out.println("INFO: getUserDetailsMethodTest passed");
        System.out.println("---------------------------");
    }



    @Test
    public void createUserMethodTest() {
        System.out.println("INFO: createUserMethodTest started");
        HttpResponse response = null;

        if(userList.size() == 0) {
            // fill userList in case it's empty to get existing users
            getUsersMethodTest();
        }

        String user = createNewUserName();
        try {
            HttpEntity entity = createNewUserDetailsEntity(user);

            httpClient =
                    HttpClientBuilder.create().setDefaultCredentialsProvider(credentialsProvider).build();

            HttpPut httpPut = new HttpPut(
                            Const.ARTIFACTORY_URL
                            .concat(Const.GET_USERS_METHOD)
                            .concat("/")
                            .concat(user));

            httpPut.setEntity(entity);

            response = httpClient.execute(httpPut);

        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        } finally {
            try {
                httpClient.close();
            } catch (Exception ignored) {}
        }

        Assert.assertEquals("ERROR: createUserMethodTest failed. Response code not as expected ",
                HttpStatus.SC_CREATED,
                response.getStatusLine().getStatusCode());

        // users' counter before creation
        int usersCount = userList.size();
        //update userList
        getUsersMethodTest();
        Assert.assertTrue("ERROR: createUserMethodTest failed. New Created user can't be found.",
                userList.size() == usersCount + 1);

        // validate user created without admin privileges
        for(User userObj : userList) {
            if(userObj.getName().equals(user)) {
                getUserDetails(user);
                Assert.assertFalse("ERROR: createUserMethodTest failed. User " +
                                userDetails.getName() + " created with admin privileges",
                    userDetails.isAdmin());
                System.out.println("INFO: User " + user + " created without admin permissions.");
                break;
            }
        }

        System.out.println("INFO: createUserMethodTest passed");
        System.out.println("---------------------------");
    }

    @Test
    public void updateExistingUserToAdminMethodTest(){
        System.out.println("INFO: updateExistingUserToAdminMethodTest started");
        HttpResponse response = null;

        if(userList.size() == 0) {
            // fill userList in case it's empty to get existing users
            getUsersMethodTest();
        }

        // find not admin user
        String userName = findUserWithoutAdminPrivileges();

        Assert.assertNotNull("Test failed", userName);

        try {
            httpClient =
                    HttpClientBuilder.create().setDefaultCredentialsProvider(credentialsProvider).build();

            HttpPost httpPost = new HttpPost(
                    Const.ARTIFACTORY_URL
                            .concat(Const.GET_USERS_METHOD)
                            .concat("/")
                            .concat(userName));

            HttpEntity entity = updateToAdminEntity();
            httpPost.setEntity(entity);
            response = httpClient.execute(httpPost);

            Assert.assertEquals("Response code not as expected ",
                    HttpStatus.SC_OK,
                    response.getStatusLine().getStatusCode());

        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        } finally {
            try {
                httpClient.close();
            } catch (Exception ignored) {}
        }

        // validate user has admin privileges
        for(User userObj : userList) {
            if(userObj.getName().equals(userName)) {
                getUserDetails(userName);
                Assert.assertTrue("ERROR: updateExistingUserToAdminMethodTest failed. "+ userObj.getName() + " is not admin",
                        userDetails.isAdmin());
                System.out.println("INFO: User " + userDetails.getName() + " now has admin permissions.");
            }
        }

        System.out.println("INFO: updateExistingUserToAdminMethodTest passed");
        System.out.println("---------------------------");
    }

    @Test
    public void deleteExistingUserMethodTest() {
        System.out.println("INFO: deleteExistingUserMethodTest started");
        HttpResponse response = null;

        if(userList.size() == 0) {
            // fill userList in case it's empty to get existing users
            getUsersMethodTest();
        }

        // find not admin user
        String userName = findUserWithoutAdminPrivileges();

        try {
            httpClient =
                    HttpClientBuilder.create().setDefaultCredentialsProvider(credentialsProvider).build();

            HttpDelete httpDelete = new HttpDelete(
                    Const.ARTIFACTORY_URL
                            .concat(Const.GET_USERS_METHOD)
                            .concat("/")
                            .concat(userDetails.getName()));



            response = httpClient.execute(httpDelete);

        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        } finally {
            try {
                httpClient.close();
            } catch (Exception ignored) {}
        }

        Assert.assertEquals("Response code not as expected ",
                HttpStatus.SC_OK,
                response.getStatusLine().getStatusCode());

        // update userList
        getUsersMethodTest();

        // validate user is not exist
        for(User userObj : userList) {
            if(userObj.getName().equals(userName)) {

                System.out.println("ERROR: deleteExistingUserMethodTest failed. " +
                        "User " + userName + " exists despite deletion.");
                Assert.fail();
            }
        }

        System.out.println("INFO: deleteExistingUserMethodTest passed");
        System.out.println("---------------------------");
    }

    private String findUserWithoutAdminPrivileges() {
        for(User userObj : userList) {
            getUserDetails(userObj.getName());
            if(!userDetails.isAdmin()) {
                System.out.println("INFO: User " + userDetails.getName() + " is not admin");
                return userObj.getName();
            }
        }
        System.out.println("ERROR: There were not found users without admin privileges");
        return null;
    }

    private HttpEntity createNewUserDetailsEntity (String username) throws UnsupportedEncodingException {

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("name", username);
        jsonObject.put("password", username);
        jsonObject.put("email", username.concat("@test.com"));
        jsonObject.put("admin", false);

        HttpEntity e = new StringEntity(jsonObject.toString());
        ((StringEntity) e).setContentType("application/json;charset=utf-8");
        return  e;
    }

    private UserDetails getUserDetails(String userName) {
        httpClient =
                HttpClientBuilder.create().setDefaultCredentialsProvider(credentialsProvider).build();


        HttpGet httpGet = new HttpGet(
                Const.ARTIFACTORY_URL
                        .concat(Const.GET_USERS_METHOD)
                        .concat("/")
                        .concat(userName));

        httpGet.setConfig(requestConfig);

        try {
            HttpResponse response = httpClient.execute(httpGet);

            System.out.println("INFO: Response code: " + response.getStatusLine().getStatusCode());
            Assert.assertEquals("Response code not as expected ",
                    HttpStatus.SC_OK,
                    response.getStatusLine().getStatusCode());

            userDetails = mapper.readValue(response.getEntity().getContent(),
                    mapper.getTypeFactory().constructType(UserDetails.class));

        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        } finally {
            try {
                httpClient.close();
            }
            catch (Exception ignored) {}
        }
        return userDetails;
    }

    private HttpEntity updateToAdminEntity () throws UnsupportedEncodingException {

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("admin", true);

        HttpEntity e = new StringEntity(jsonObject.toString());
        ((StringEntity) e).setContentType("application/json;charset=utf-8");
        return  e;
    }

    private String createNewUserName() {
        return "user".concat(sdf.format(new Timestamp(System.currentTimeMillis())));
    }

    @After
    public void tearDown() {

    }
}
